package DiGraph_A5;

import java.util.HashMap;

public class Node {
	
	public long id;
	public String label;
	//public long distance;
	public boolean known;
	
	HashMap<String, Edge> source = new HashMap<String, Edge>();
	HashMap<String, Edge> dest = new HashMap<String, Edge>();
	
	//hashmap for source edge -- incoming -- slabel
	//hashmap for dest edge -- outgoing -- dlabel
		//node - key
		//edge - value
	
	
	public Node(long id, String label) {
		this.id = id;
		this.label = label;
		
		//this.distance = Integer.MAX_VALUE;
		this.known = false;
		
	}

}
