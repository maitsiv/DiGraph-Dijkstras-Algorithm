package DiGraph_A5;

public class DiGraphPlayground {

  public static void main (String[] args) {
  
      // thorough testing is your responsibility
      //
      // you may wish to create methods like 
      //    -- print
      //    -- sort
      //    -- random fill
      //    -- etc.
      // in order to convince yourself your code is producing
      // the correct behavior
     // exTest();
	  //efficiency();	
	 // testA();
	  //testB();
	  testC();
  }
  
    public static void exTest(){
      DiGraph d = new DiGraph();
      d.addNode(1, "f");
      d.addNode(3, "s");
      d.addNode(7, "t");
      d.addNode(0, "fo");
      d.addNode(4, "fi");
      d.addNode(6, "si");
      d.addEdge(0, "f", "s", 0, null);
      d.addEdge(1, "f", "si", 0, null);
      d.addEdge(2, "s", "t", 0, null);
      d.addEdge(3, "fo", "fi", 0, null);
      d.addEdge(4, "fi", "si", 0, null);
      d.addEdge(5, "fi", "f", 0, null);
      d.delNode("f");
     
      System.out.println("numEdges: "+d.numEdges());
      System.out.println("numNodes: "+d.numNodes());
    }
    
    public static void testA() {
    	DiGraph d = new DiGraph();
    	d.addNode(0, "a");
    	d.addNode(1, "b");
    	d.addNode(2, "c");
    	d.addNode(3, "d");
    	d.addNode(4,  "e");
    	d.addNode(5,  "f");

    	d.addEdge(0,  "b", "a", 15, "");
    	d.addEdge(1,  "b", "c", 2, "");
    	d.addEdge(2,  "a", "f", 1, "");
    	d.addEdge(3,  "a", "d", 8, "");
    	d.addEdge(4,  "a", "c", 5, "");
    	d.addEdge(6,  "b", "e", 13, "");
    	d.addEdge(7,  "c", "d", 1, "");
    	d.addEdge(8,  "c", "f", 7, "");
    	d.addEdge(9,  "d", "e", 3, "");
    	d.addEdge(10,  "e", "f", 2, "");
    



    	
    	ShortestPathInfo[] sp = d.shortestPath("a");
    	
    	for (int i = 0; i < d.numNodes; i++) {
    		System.out.println("to node: " + sp[i].getDest());
    		System.out.println("shortest path: " +sp[i].getTotalWeight());
    	}
    	
    	System.out.println("numEdges: "+d.numEdges());
        System.out.println("numNodes: "+d.numNodes());
    	DiGraph a = new DiGraph();
    	

    }
    
    public static void efficiency(){
    	
    	DiGraph d = new DiGraph();
    	
    	for (int i = 0; i < 1000000; i++) {
    		d.addNode(i, "" + i);
    		if (i > 0) {
    			int j = i - 1;
    			d.addEdge(i, "" + i, "" + j, i, null);
    		}
    
    	}
        System.out.println("numEdges: "+d.numEdges());
        System.out.println("numNodes: "+d.numNodes());
    	
    }
    
    
    public static void testB() {
    	
    	DiGraph d = new DiGraph();
    	/*d.addNode(6, null);
    	d.addNode(-1, "e");
    	d.addNode(6, "hello");
    	d.addNode(6, "hey");
        d.addNode(1, "hey");
        d.addNode(2, "hey");
        d.addNode(5, "ho");
        d.delNode("yo");
        d.delNode("hey");
        d.delNode(null);
        
        d.addEdge(1, "hello", "hey", 4, "a");
        d.addEdge(1, "ho", "hey", 3, "b");
        d.addEdge(7, "hello", "ho", 4, "a");
        d.addEdge(8, "ho", "hey", 2, "c");
        d.addEdge(9, "hi", "hey", 4, "a");
        d.addEdge(0, "ho", "ho", "d");*/
        
        d.addNode(6, null);
        d.addNode(-1, null);
        d.addNode(6, "hello");
        d.addNode(3, "hey");
        d.addNode(5, "hey");
        d.addNode(6, "hey");
        d.addNode(2, "dog");
        d.addNode(1, "five");
          d.addNode(7, "yell");
          d.addNode(9, "b");
          d.addNode(12, "k");
//        d.delNode("sup");
//        d.delNode("hey");
//        d.delNode(null);
//        
        d.addEdge(3, "boo", "hey", 5, "love");
        

        d.addEdge(3, "dog", "h", "fight");
        

        d.addEdge(3, "hello", "hey", "fight");
        

        d.addEdge(7, "hello", "hey", 5, "fight");
        

        d.addEdge(7, "hello", "hey", "sor");
        d.addEdge(10, "hello", "hey", "sor");
        d.addEdge(2, "dog", "five", 2, "love");
        d.delNode(null);
        d.delNode("live");
        //d.delNode("five");
        d.addEdge(9, "five", "hello", "a");


        d.delEdge(null, null);
        d.delEdge("dog", "hey");

        
        System.out.println("numEdges: "+d.numEdges());
        System.out.println("numNodes: "+d.numNodes());
    	

    }
    
    public static void testC() {

DiGraph d = new DiGraph();
d.addNode(0, "a");
d.addNode(1, "b");
d.addNode(2, "c");
d.addNode(3, "d");
d.addNode(4,  "e");
d.addNode(5,  "f");

d.addEdge(0,  "b", "a", 15, "");
d.addEdge(1,  "b", "c", 2, "");
d.addEdge(2,  "a", "f", 1, "");
d.addEdge(3,  "a", "d", 8, "");
d.addEdge(4,  "a", "c", 5, "");
d.addEdge(6,  "b", "e", 13, "");
d.addEdge(7,  "c", "d", 1, "");
d.addEdge(8,  "c", "f", 7, "");
d.addEdge(9,  "d", "e", 3, "");
d.addEdge(10,  "e", "f", 2, "");
  d.delEdge("b", "c");
// d.delEdge("c", "d");
//  d.delEdge("a", "d");







ShortestPathInfo[] sp = d.shortestPath("b");


for (int i = 0; i < d.numNodes; i++) {
System.out.println("to node: " + sp[i].getDest());
System.out.println("shortest path: " +sp[i].getTotalWeight());
}




d.delEdge("a", "d");
ShortestPathInfo[] sg = d.shortestPath("b");


for (int i = 0; i < d.numNodes; i++) {
    System.out.println("to node: " + sg[i].getDest());
    System.out.println("shortest path: " +sg[i].getTotalWeight());
    }
    }
}
