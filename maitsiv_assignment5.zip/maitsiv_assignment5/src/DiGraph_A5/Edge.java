package DiGraph_A5;

public class Edge {
	
	public long id;
	public String sourcelabel;
	public String destlabel;
	public long weight;
	public String edgelabel;
	
	public Edge(long id, String sl, String dl, long weight, String el) {
		this.id = id;
		this.sourcelabel = sl;
		this.destlabel = dl;
		this.weight = weight;
		this.edgelabel = el;
	}
	
	public Edge(long id, String sl, String dl, String el) {
		this.id = id;
		this.sourcelabel = sl;
		this.destlabel = dl;
		this.weight = 1;
		this.edgelabel = el;
	}

}
