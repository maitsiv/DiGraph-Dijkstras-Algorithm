package DiGraph_A5;

public class EntryPair {

	public long weight;
	public Node node;
	


public EntryPair(long weight, Node node) {
	this.weight = weight;
	//this.spi = spi;
	this.node = node;
}

}
