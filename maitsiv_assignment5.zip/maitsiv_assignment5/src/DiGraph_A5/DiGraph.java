package DiGraph_A5;

import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

public class DiGraph implements DiGraphInterface {

  
	HashMap<Long,Node> idNode = new HashMap<Long, Node>();
	HashMap<String,Node> labelNode = new HashMap<String,Node>();
	HashMap<Long,Edge> idEdge = new HashMap<Long, Edge>();
	long numNodes;
	long numEdges;

  public DiGraph ( ) { // default constructor
    
  }

@Override
public boolean addNode(long idNum, String label) {
	if (idNum < 0) {
		return false;
	} else if (idNode.containsKey(idNum)) {
		return false;
	} if (label == null || labelNode.containsKey(label)) {
		return false;
	} else {
		Node newNode = new Node(idNum, label);
		idNode.put(idNum, newNode);
		labelNode.put(label, newNode);
		numNodes++;
		return true;

	}
}

@Override
public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
	
	Node sourceNode = labelNode.get(sLabel);
	Node destNode = labelNode.get(dLabel);
	
	if (idNum < 0) {
		return false;
	} else if (idEdge.containsKey(idNum)) {
		return false;
	} if (!(labelNode.containsKey(sLabel))) {
		return false;
	} else if (!(labelNode.containsKey(dLabel))) {
		return false;
	} if (sourceNode.dest.containsKey(dLabel))  {
		return false;
	} else if (destNode.source.containsKey(sLabel)){
		return false;		
	} else {		
	 	Edge newEdge = new Edge(idNum, sLabel, dLabel, weight, eLabel);
	 	idEdge.put(idNum, newEdge);
	 	sourceNode.dest.put(dLabel, newEdge);
	 	destNode.source.put(sLabel, newEdge);
	 	numEdges++;
		return true;
	}
		
}
public boolean addEdge(long idNum, String sLabel, String dLabel, String eLabel) {
	Node sourceNode = labelNode.get(sLabel);
	Node destNode = labelNode.get(dLabel);
	
	if (idNum < 0) {
		return false;
	} else if (idEdge.containsKey(idNum)) {
		return false;
	} if (!(labelNode.containsKey(sLabel))) {
		return false;
	} else if (!(labelNode.containsKey(dLabel))) {
		return false;
	} if (sourceNode.dest.containsKey(dLabel))  {
		return false;
	} else if (destNode.source.containsKey(sLabel)){
		return false;		
	} else {		
	 	Edge newEdge = new Edge(idNum, sLabel, dLabel, eLabel);
	 	idEdge.put(idNum, newEdge);
	 	sourceNode.dest.put(dLabel, newEdge);
	 	destNode.source.put(sLabel, newEdge);
	 	numEdges++;
		return true;
	}
}

@Override
public boolean delNode(String label) {
	
	Node deleteNode = labelNode.get(label);
	
	if (!(labelNode.containsKey(label))) {
		return false;
	} else {
		if (deleteNode == null) {
			return false;
		}
		else {
			long delId = deleteNode.id;
			String delLabel = deleteNode.label;
			
			for (String key: deleteNode.source.keySet()) {
				idEdge.remove(labelNode.get(key).dest.get(label).id);
				labelNode.get(key).dest.remove(label);
				numEdges--;
			}
			for (String key: deleteNode.dest.keySet()) {
				idEdge.remove(labelNode.get(key).source.get(label).id);
				labelNode.get(key).source.remove(label);
				numEdges--;
			}			
		
			idNode.remove(delId); 
			labelNode.remove(delLabel);
			numNodes--;
			return true;
		}
	}

	
}

@Override
public boolean delEdge(String sLabel, String dLabel) {
	Node sourceNode = labelNode.get(sLabel);
	Node destNode = labelNode.get(dLabel);
	if (sourceNode == null || destNode == null) {
		return false;
	}
	else if (!sourceNode.dest.containsKey(dLabel))  {
		return false;
	}
	else if ((!destNode.source.containsKey(sLabel))) {
			return false;	
	} else {
		
		Edge deleteEdge = sourceNode.dest.get(dLabel);
		long deleteId = deleteEdge.id;
		idEdge.remove(deleteId);
		sourceNode.dest.remove(dLabel);
		destNode.source.remove(sLabel);		
		numEdges--;
		return true;
	}
		
}

@Override
public long numNodes() {
	return this.numNodes;
}

@Override
public long numEdges() {
	return this.numEdges;
}

@Override
public ShortestPathInfo[] shortestPath(String label) {
	if (!labelNode.containsKey(label)) {
		return null;
	} else {
		
	int nodes = labelNode.size();
	ShortestPathInfo[] shortestPaths = new ShortestPathInfo[nodes];
	
	Comparator<EntryPair> comp = (ep1, ep2)->{
		if(ep1.weight < ep2.weight) {
			return -1;
		} else if(ep1.weight > ep2.weight) {
			return 1;
		} else {
			return 0;
		}
	};
	
	PriorityQueue<EntryPair> pq = new PriorityQueue<EntryPair>(comp);	
	HashMap<String, ShortestPathInfo> labelShortestPath = new HashMap<String, ShortestPathInfo>();
	
	//create shortest path info object array and populate fields
	int i = 0;	
	for (String key: labelNode.keySet()) {
		shortestPaths[i] = new ShortestPathInfo(key, -1);
		labelShortestPath.put(key, shortestPaths[i]);
		i++;
	}			
	//set start node distance to 0
	Node startNode = labelNode.get(label);
	ShortestPathInfo spiStart = labelShortestPath.get(label);
	spiStart.setTotalWeight(0);
	//put start node in pq		
	pq.add(new EntryPair(0, startNode));

	while (!pq.isEmpty()) {	
		startNode = pq.poll().node;
		
		if (startNode.known == false) {
			for (String key: startNode.dest.keySet()) {
				ShortestPathInfo currentSpi = labelShortestPath.get(key);
				ShortestPathInfo startSpi = labelShortestPath.get(startNode.label);
			
				if (currentSpi.getTotalWeight() == -1) {
					currentSpi.setTotalWeight(startNode.dest.get(key).weight);
					currentSpi.setTotalWeight(currentSpi.getTotalWeight() + startSpi.getTotalWeight());
				} else {
					long newWeight = startSpi.getTotalWeight() + startNode.dest.get(key).weight; //startnode weight + edge weight
					if (currentSpi.getTotalWeight() > newWeight) {
						currentSpi.setTotalWeight(newWeight);
					}
				}
				EntryPair ep = new EntryPair(currentSpi.getTotalWeight(), labelNode.get(key));
				pq.add(ep);							
			}
			startNode.known = true;
		}	
	}	
	int j = 0;
	for (String key: labelShortestPath.keySet()) {
		shortestPaths[j].setTotalWeight(labelShortestPath.get(key).getTotalWeight());
		labelNode.get(shortestPaths[j].getDest()).known = false;
		j++;
	}	

return shortestPaths; 
}
}
}

